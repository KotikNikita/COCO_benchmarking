Code written by:
- David Eriksson <eriksson@uber.com>
